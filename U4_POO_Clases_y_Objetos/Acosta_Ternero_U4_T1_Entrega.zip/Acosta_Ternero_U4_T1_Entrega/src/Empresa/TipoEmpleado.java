package Empresa;

public enum TipoEmpleado {
    tecnico, administrativo, directivo
}
