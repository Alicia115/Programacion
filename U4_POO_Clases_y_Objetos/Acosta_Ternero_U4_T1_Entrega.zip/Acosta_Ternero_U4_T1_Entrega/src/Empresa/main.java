package Empresa;

public class main {
    public static void main(String[] args) {

        Empresa e1 =new Empresa("Loli");
        Departamento d1= new Departamento("departamentito", "Camas","+43" );
        Departamento d2= new Departamento("depaaaartem", "Tomares","+43" );
        Departamento d3= new Departamento("departamenent","+85" );
        Empleado em1= new Empleado("Alba Perez", "111111", "111222333", TipoEmpleado.administrativo);
        Empleado em2= new Empleado("Olga Rodriguez", "222222", "222333444");
        Empleado em3= new Empleado("Andrea Sanchez", "333666", "333444555", TipoEmpleado.directivo);
        Empleado em4= new Empleado("Pedro Pavon", "555444", "444555666", TipoEmpleado.administrativo);
        Empleado em5= new Empleado("Gonzalo Perez", "888888", "666777888", TipoEmpleado.directivo);
        Empleado em6= new Empleado("Angela Serion", "666666", "777888999", TipoEmpleado.tecnico);
        Empleado em7= new Empleado("Miguel Pedroso", "333333", "999111222");
        Empleado em8= new Empleado("Alicia Acosta", "777777", "444558889", TipoEmpleado.administrativo);


        e1.addDepartamento(d1);
        e1.addDepartamento(d2);
        e1.addDepartamento(d3);
        d1.addempledo(em1);
        d1.addempledo(em2);
        d1.addempledo(em8);
        d2.addempledo(em3);
        d2.addempledo(em4);
        d2.addempledo(em5);
        d3.addempledo(em6);
        d3.addempledo(em7);


        System.out.println(e1);
        System.out.println("Cantidad empleados: " +Empleado.getCantempleado());
        System.out.println("Cantidad departamentos: "+ Departamento.getCantdepartamento());



    }
}
