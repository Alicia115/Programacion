package Empresa;

import java.util.Calendar;

public class Empleado {

    private String nombre;
    private String ss;
    private String telefono;
    Calendar fecha;
    private TipoEmpleado tipoempleado;
    private static int cantempleado=0;

    public Empleado(String nombre, String ss, String telefono, TipoEmpleado tipoempleado) {
        this.nombre = nombre;
        this.ss = ss;
        this.telefono = telefono;
        this.tipoempleado = tipoempleado;
        this.fecha= Calendar.getInstance();
        cantempleado++;
    }

    public Empleado(String nombre, String ss, String telefono) {
        this.nombre = nombre;
        this.ss = ss;
        this.telefono = telefono;
        this.tipoempleado = TipoEmpleado.tecnico;
        this.fecha= Calendar.getInstance();
        cantempleado++;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSs() {
        return ss;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }

    public TipoEmpleado getTipoempleado() {
        return tipoempleado;
    }

    public void setTipoempleado(TipoEmpleado tipoempleado) {
        this.tipoempleado = tipoempleado;
    }

    public static int getCantempleado() {
        return cantempleado;
    }

    @Override
    public String toString() {

        String dia, mes, annio;

        dia = Integer.toString(fecha.get(Calendar.DATE));
        mes = Integer.toString(fecha.get(Calendar.MONTH));
        annio = Integer.toString(fecha.get(Calendar.YEAR));

        return "Empleado{" +
                "nombre='" + nombre + '\'' +
                ", ss='" + ss + '\'' +
                ", telefono='" + telefono + '\'' +
                ", fecha=" + dia + "/" + mes+1 + "/" + annio+
                ", tipoempleado=" + tipoempleado +
                '}';
    }
}
