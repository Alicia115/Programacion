package Empresa;

import java.util.Arrays;

public class Departamento {

    private String nombre;
    private String sede;
    private String extension;
    private Empleado[]empleados;
    private static int cantdepartamento;

    public Departamento(String nombre, String sede, String extension) {
        this.nombre = nombre;
        this.sede = sede;
        this.extension = extension;
        this.empleados= new Empleado[0];
        cantdepartamento++;
    }

    public Departamento(String nombre, String extension) {
        this.nombre = nombre;
        this.extension = extension;
        this.sede="Castilleja";
        this.empleados= new Empleado[0];
        cantdepartamento++;
    }

    public void addempledo(Empleado empleado){
        empleados= Arrays.copyOf(empleados, empleados.length+1);
        empleados[empleados.length-1]=empleado;
    }

    public void restarempleado(String ss){
        Empleado[] auxiliar=new Empleado[0];

        for (int i = 0; i < empleados.length; i++) {
            if(!empleados[i].getSs().equals(ss)){
                addempledo(empleados[i]);
            }
        }
        if(auxiliar.length < empleados.length){
            empleados.equals(auxiliar);
        } else{
            System.out.println("El numero de la seguridad social de dicho empledo no se encuentra disponible");
        }

    }

    public static int getCantdepartamento() {
        return cantdepartamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public Empleado[] getEmpleados() {
        return empleados;
    }

    public void setEmpleados(Empleado[] empleados) {
        this.empleados = empleados;
    }

    @Override
    public String toString() {
        return "Departamento{" +
                "nombre='" + nombre + '\'' +
                ", sede='" + sede + '\'' +
                ", extension='" + extension + '\'' +
                ", empleados=" + Arrays.toString(empleados) +
                '}';
    }
}
